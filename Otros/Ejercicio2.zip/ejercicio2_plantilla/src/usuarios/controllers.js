import { body } from 'express-validator';

export function viewLogin(req, res) {
    // TODO: tu código aquí
    let contenido='formulario'; 
    res.render('paginas/contenido', {
        contenido,
        session: req.session
    });
}

export function doLogin(req, res) {
    body('username').escape(); // Se asegura que eliminar caracteres problemáticos
    body('password').escape(); // Se asegura que eliminar caracteres problemáticos
    const { username, password } = req.body;
    let contenido = 'error';
  if (username === 'user' && password === 'userpass') {
    req.session.logged = true;
    req.session.nombre = 'Usuario';
    contenido = 'saludo';
  } else if (username === 'admin' && password === 'adminpass') {
    req.session.logged = true;
    req.session.nombre = 'Administrador';
    req.session.esAdmin = true;
    contenido='saludoAdmin';
  } else {
    req.session.logged = false;
  }
  res.status(200);
  res.render('paginas/contenido', {
    contenido,
    session: req.session,
  });
}

export function doLogout(req, res, next) {
    delete req.session.logged;
    delete req.session.nombre;
    if(req.session.esAdmin){
        delete req.session.esAdmin;
    }
    req.session.destroy();
    
    next();
}

export function doFinish(req, res) {
    res.status(200);
    res.render('paginas/contenido', {
        contenido: 'logout', 
        session: req.session
    });
   
}
