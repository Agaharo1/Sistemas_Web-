import express from 'express';
import { config } from '../config.js';
import { viewLogin, doLogin, doLogout, doFinish } from './controllers.js';

const usuariosRouter = express.Router();
//usuariosRouter.use(express.static(config.recursos));
usuariosRouter.get('/login', viewLogin);
usuariosRouter.post('/login', doLogin);
usuariosRouter.get('/logout', doLogout,doFinish);

// TODO: Añade las rutas que faltan

export default usuariosRouter;