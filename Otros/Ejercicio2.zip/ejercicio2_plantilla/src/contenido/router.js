import express from 'express';


const contenidoRouter = express.Router();
//contenidoRouter.use(express.static(config.recursos));
contenidoRouter.get('/normal', (req, res) => {
    let contenido = 'noPermisos';
    if (req.session.logged) {
        contenido = 'normal';
    }
    res.status(200);
    res.render('paginas/contenido', {
        contenido,
        session: req.session
    });
});

contenidoRouter.get('/admin', (req, res) => {
    // TODO: tu código aquí
    let contenido = 'noPermisos';
    if (req.session.logged) {
        contenido = 'denegado';
        if(req.session.esAdmin){
            contenido = 'admin';
        }
    }
    res.status(200);
    res.render('paginas/contenido', {
        contenido,
        session: req.session
    });
});

export default contenidoRouter;